## Create React App Visualization

This assessment was bespoke handcrafted for Ganga.

Read more about this assessment [here](https://react.eogresources.com)
